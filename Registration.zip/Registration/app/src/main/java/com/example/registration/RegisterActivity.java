package com.example.registration;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        TextView btn=findViewById(R.id.alreadyHaveAccount);
        SharedPreferences sharedPreferences = getSharedPreferences("com.example.anirudh", Context.MODE_PRIVATE);
        final SharedPreferences.Editor editor = sharedPreferences.edit();

        final EditText name = findViewById(R.id.inputUsername);
        final EditText email = findViewById(R.id.inputEmail);
        final EditText address = findViewById(R.id.inputAddress);
        final EditText phone = findViewById(R.id.inputPhone);
        final EditText password = findViewById(R.id.inputPassword);
        Button REG = findViewById(R.id.btnRegister);
        TextView HaveAcc = findViewById(R.id.alreadyHaveAccount);

        REG.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String emailEnteredByUser = email.getText().toString();
                String passwordEnteredByUser = password.getText().toString();

                if(name.equals("") || email.equals("") || address.equals("") || phone.equals("") || password.equals("")) {
                    Toast.makeText(RegisterActivity.this, "Please Enter credentials", Toast.LENGTH_SHORT).show();
                }
                else {
                    editor.putString(emailEnteredByUser, passwordEnteredByUser);
                    editor.apply();

                    Toast.makeText(RegisterActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();
                }
            }
        });

        HaveAcc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent goToLoginActivity = new Intent(RegisterActivity.this, LoginActivity.class);
                startActivity(goToLoginActivity);
            }
        });


    }
}
